# 哈基米 — GitHub 自动编译 APK 工程

这是《哈基米》小型 3D 枪战 FPS 游戏的 Android 打包工程。
游戏本身是 `www/index.html`（Capacitor 套壳的网页游戏），
把这个工程传到 GitHub 后，GitHub Actions 会自动编译出 APK 安装包。

- **应用名**：哈基米
- **包名**：`com.hajimi.game`
- **应用图标**：用的就是你上传的那张动漫图（中央正方形裁切，1024×1024，
  已按 Android 规范生成 mdpi / hdpi / xhdpi / xxhdpi / xxxhdpi 五档
  `ic_launcher.png`、`ic_launcher_round.png` 和自适应图标前景图）
- **游戏内容**：选地图（城市街区 / 沙漠小镇 / 仓库夜战）、选人物、
  开镜、改键位、灵敏度、陀螺仪瞄准，电脑和手机都能玩；
  还支持局域网联机：同一 Wi-Fi 下两台设备真人 1v1（见第六节）

## 一、准备

1. 在 GitHub 上新建一个仓库（名字随便起，比如 `hajimi-game`），
   **不要**勾选“Add a README file”，建一个空仓库。
2. 把这个 zip 解压，得到 `hajimi-apk` 文件夹，里面的东西就是仓库的全部内容。

## 二、传到 GitHub

在解压出的 `hajimi-apk` 文件夹里打开终端，依次执行：

```bash
git init
git add .
git commit -m "哈基米 v1.0"
git branch -M main
git remote add origin https://github.com/<你的用户名>/<你的仓库名>.git
git push -u origin main
```

> 没有装 git 的话，也可以在 GitHub 仓库页面点 **Add file → Upload files**，
> 把 `hajimi-apk` 里的所有文件和文件夹直接拖进去上传（注意不要把
> `node_modules` 传上去，zip 里本来就没有）。

## 三、等自动编译

1. 推送完成后，打开仓库页面的 **Actions** 标签页，
   会看到一个正在跑的 **Build APK** 任务。
2. 等它跑完变绿（一般 3–8 分钟）。如果变红点进去看报错，
   常见原因是网络问题，点 **Re-run jobs** 重新跑一次就行。
3. 点进那次成功的运行记录，拉到最下面的 **Artifacts**，
   下载 **hajimi-apk**，解压后里面就是 `app-debug.apk`。

## 四、安装到手机

1. 把 `app-debug.apk` 传到手机上（微信/QQ/数据线都行）。
2. 手机上点开 APK 安装，提示“允许安装未知应用”时按提示打开开关，
   再点安装即可。
3. 桌面上就会出现“哈基米”图标（就是你那张图），点开就能玩。

## 五、以后想改游戏怎么办

- 改游戏内容：替换 `www/index.html`，然后重新 `git push`，
  Actions 会自动再编一个新 APK。
- 换图标：替换 `resources/icon.png`（1024×1024 正方形），
  再把 `android/app/src/main/res/mipmap-*/` 里的三组图标按同样尺寸换掉，
  或者重新跑一遍本机的图标生成步骤。
- 本地直接编译（需要装 Android Studio / JDK 17）：

```bash
npm install
npx cap sync android
cd android && ./gradlew assembleDebug
# APK 在 android/app/build/outputs/apk/debug/app-debug.apk
```


## 六、局域网联机怎么玩（3 分钟真人 1v1）

联机已经在游戏里了（`www/index.html`，所以编出来的 APK 里也有），
不用另外装东西，也不用游戏服务器：两台设备用 WebRTC 在局域网内直连，
连接码只用来牵线。

**前提：** 两台设备连同一个 Wi-Fi；或者一台开热点、另一台连上这个热点。
进大厅先把模式切到「局域网联机」，各自选好人物，地图以房主选的为准。

1. 房主点「我是房主 · 创建房间」→「生成连接码」，把码①发给朋友
   （微信发过去就行；码比较长，复制时别漏字）。
2. 朋友点「我是客人 · 加入房间」，把码①粘贴进去，点「生成码②」，
   把码②发回给房主。
3. 房主把码②粘贴到下面，点「确认连接」，状态变绿显示「已连接」后，
   房主点「开始联机战斗」开局。

**规则：** 3 分钟真人 1v1，不刷电脑敌人；出生在地图两端，
击杀 +100（爆头 +150），被击杀后 3 秒在出生点复活；小地图上的红点就是对方，
结束后按击杀数分胜负。

**连不上怎么办：** 先确认两台设备在同一个 Wi-Fi 下，再重新生成一对码牵线；
码①/码②粘贴不完整是最常见的原因。断开后重新生成连接码再连即可。

**一个人也能先测：** 同一台设备的两个标签页打开游戏，也能用这套码互连测试，
不用等朋友到场再试。

> 注意：联机还没在两台真机上实测过，第一次和朋友试的时候按上面三步走，
> 如果直连失败，把当时的提示发回来再修。

## 工程结构

```
hajimi-apk/
├── package.json                 Capacitor 7 依赖（core / cli / android）
├── capacitor.config.json        appId=com.hajimi.game，appName=哈基米，webDir=www
├── www/
│   └── index.html               游戏本体（单个自包含 HTML）
├── resources/
│   └── icon.png                 应用图标 1024×1024（用户原图中央裁切）
├── android/                     Capacitor 生成的 Android 原生工程
│   ├── app/src/main/
│   │   ├── AndroidManifest.xml  应用名、图标引用
│   │   └── res/mipmap-*/        各密度图标 + 自适应图标
│   └── gradlew                  Gradle 包装器（Actions 里用它编译）
└── .github/workflows/
    └── build-apk.yml            自动编译 APK 的工作流
```

> 这个 APK 是 debug 测试包，可以直接安装玩；如果以后要上架应用商店，
> 需要再做 release 签名包，那一步要另外配签名密钥。
