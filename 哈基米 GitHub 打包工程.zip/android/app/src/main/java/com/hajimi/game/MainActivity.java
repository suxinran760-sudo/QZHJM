package com.hajimi.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
